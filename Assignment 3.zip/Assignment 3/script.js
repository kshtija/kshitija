//click on close button to delete the current list item 
var close = document.getElementsByClassName("fa-times");
// console.log(close);
for(var i = 0; i < close.length; i++) {
    close[i].onclick = function () {
        var div = this.parentElement;
        // console.log(div);
        this.closest(".subject").remove(); 
    }
}

// Create a new list item when clicking on the "Add" button
function newElement(){
    var li = document.createElement("li");
    console.log(li);
    // li.className = "note-list";
    // li.className = "list";
    li.className = "subject";
    var inputValue = document.getElementById("add-input").value;
    console.log(inputValue);
    var t = document.createTextNode(inputValue);
    console.log(t);
    li.appendChild(t);
    // li.setAttribute(
    //     "style",
    //     "padding-left: 35px; padding-right: 35px; margin-top: 10px; padding: 5px;  margin-bottom: 10px; border-bottom: 0.1px solid #ccc; border-left: 5px solid #efefef;"
    //     // padding-bottom: 23px; 
    // );
    li.setAttribute(
        "style",
        "margin-top: 10px;"
    );
    console.log(li);
    if (inputValue === '') {
        alert("You must write something!");
    } else {
        document.getElementById("list").appendChild(li);
    }
    document.getElementById("add-input").value = "";
 
    // var span = document.createElement("SPAN");
    // console.log(span);
    // var txt = document.createTextNode("\u00D7");
    // console.log(txt);
    // span.className = "close";
    // span.appendChild(txt);
    // li.appendChild(span);

    var span = document.createElement("SPAN");
    console.log(span);
    span.className = "fa fa-pencil-square-o";
    li.appendChild(span);
    span.setAttribute(
        "style",
        "color: #228B22; cursor: pointer; margin-left: 644px; margin-top: 2px" 
    );

    var span = document.createElement("SPAN");
    console.log(span);
    span.className = "fa fa-times";
    li.appendChild(span); 
    span.setAttribute(
        "style",
        "color: #DC143C; cursor: pointer; margin-top: 1px;"    
    );

    var close = document.getElementsByClassName("fa-times");
    console.log(close);
    for(var i = 0; i < close.length; i++) {
        close[i].onclick = function () {
            var div = this.parentElement;
            // console.log(div);
            this.closest(".subject").remove(); 
        }
    }
}