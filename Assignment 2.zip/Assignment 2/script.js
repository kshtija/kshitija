var btn = document.querySelector("button");
var msg = document.getElementById("msg");
var msg1 = document.getElementById("msg1");
var msg2 = document.getElementById("msg2");
var msg3 = document.getElementById("msg3");
var msg4 = document.getElementById("msg4");
var msg5 = document.getElementById("msg5");
var msg6 = document.getElementById("msg6");
var msg7 = document.getElementById("msg7");
var msg8 = document.getElementById("msg8");

btn.onclick = function () {
    // var firstNo = parseInt(document.getElementById("num1").value);
    
    // var result = firstNo.toString().length;

    // msg.innerHTML = "<h4>" + result + "</h4>";

    var txt = document.getElementById("txt1").value;

    function lengthOfString (txt) {
        let result = txt.length;
        return result;
    }
    msg.innerHTML = "<h4>" + lengthOfString (txt) + "</h4>";

    function countUpper (txt) {
        var upper = 0;
        for (var i = 0; i < txt.length; i++) {
            if (txt[i] >= "A" && txt[i] <= "Z") {
                upper++;
            }
        }
        return upper;
    }
    msg1.innerHTML = "<h4>" + countUpper (txt) + "</h4>";

    function countLower (txt) {
        var lower = 0;
        for (var i = 0; i < txt.length; i++) {
            if (txt[i] >= "a" && txt[i] <= "z") {
                lower++;
            }
        }
        return lower;
    }
    msg2.innerHTML = "<h4>" + countLower (txt) + "</h4>";

    function countDigit (txt) {
        var digit = 0;
        for (var i = 0; i < txt.length; i++) {
            if (txt[i] >= "0" && txt[i] <= "9") {
                digit++;
            }
        }
        return digit;
    }
    msg3.innerHTML = "<h4>" + countDigit (txt) + "</h4>";

    function vowels (txt) {
        var vowels = 0;
        for (var i = 0; i < txt.length; i++) {
            if (txt[i] === "A" || txt[i] === "E" || txt[i] === "I" || txt[i] === "O" || txt[i] === "U" || 
            txt[i] === "a" || txt[i] === "e" || txt[i] === "i" || txt[i] === "o" || txt[i] === "u") {
                vowels++;
            } 
        }
        return vowels;
    }
    msg4.innerHTML =  "<h4>" + vowels (txt) + "</h4>";

    function consonants (txt) {
        var consonants = 0, vowels = 0, digit = 0, space = 0, special = 0;
        for (var i = 0; i < txt.length; i++) {
            if (txt[i] === "A" || txt[i] === "E" || txt[i] === "I" || txt[i] === "O" || txt[i] === "U" || 
            txt[i] === "a" || txt[i] === "e" || txt[i] === "i" || txt[i] === "o" || txt[i] === "u") {
                vowels++;
            } else if (txt[i] >= "0" && txt[i] <= "9") {
                digit++;
            } else if (txt[i] == " ") {
                space++;
            } else if (txt[i] == "!" || txt[i] == "@" || txt[i] == "#" || txt[i] == "$" || txt[i] == "%" || txt[i] == "&" || txt[i] == "(" || txt[i] == ")" || txt[i] == "*") {
                special++;
            }
            else {
                consonants++;
            }
        }
        return consonants;
    }
    msg5.innerHTML = "<h4>" + consonants (txt) + "</h4>";

    function space (txt) {
        var space = 0;
        for (var i = 0; i < txt.length; i++) {
            if (txt[i] == " ") {
                space++;
            }
        }
        return space;
    }
    msg6.innerHTML = "<h4>" + space (txt) + "</h4>";

    function special (txt) {
        var special = 0;
        for (var i = 0; i < txt.length; i++) {
            if (txt[i] == "!" || txt[i] == "@" || txt[i] == "#" || txt[i] == "$" || txt[i] == "%" || txt[i] == "&" || txt[i] == "(" || txt[i] == ")" || txt[i] == "*") {
                special++;
            }
        }
        return special;
    }
    msg7.innerHTML = "<h4>" + special (txt) + "</h4>";

    function palindrome (txt) {
        var flag = 0;
        var len = txt.length;
        len--;
        for (var start = 0; start < len / 2; start++ , len--) {
            if (txt[start] != txt[len]) {
                flag = 1;
                break;
            }
        }
        if (flag==0) {
            return "Yes";
        } else {
            return "No";
        }
    }
    msg8.innerHTML = "<h4>" + palindrome (txt) + "</h4>";
};