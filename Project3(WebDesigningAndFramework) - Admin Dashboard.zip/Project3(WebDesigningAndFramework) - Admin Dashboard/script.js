$(document).ready(function () {
    $('[data-bs-toggle="tooltip"]').tooltip();
}
)