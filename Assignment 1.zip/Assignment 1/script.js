var btn = document.querySelector("button");
var msg = document.getElementById("msg");
var msg1 = document.getElementById("msg1");
var msg2 = document.getElementById("msg2");
var msg3 = document.getElementById("msg3");
var msg4 = document.getElementById("msg4");
var msg5 = document.getElementById("msg5");

btn.onclick = function () {
    var firstNo = parseInt(document.getElementById("num1").value);
    
    var result = firstNo.toString().length;
    msg.innerHTML = "<h4>" + result + "</h4>";
    
    function evenDigits (firstNo) {
        let count = 0;
        while (firstNo > 0) {
            let rem = firstNo % 10;
            if(rem % 2 == 0) {
                count++;
            }
            firstNo = Math.floor (firstNo / 10);
        }
        return count;
    }
    msg1.innerHTML = "<h4>" + evenDigits (firstNo) + "</h4>";

    function oddDigits (firstNo) {
        let count = 0;
        while (firstNo > 0) {
            let rem = firstNo % 10;
            if(rem % 2 != 0) {
                count++;
            }
            firstNo = Math.floor (firstNo / 10);
        }
        return count;
    }
    msg2.innerHTML = "<h4>" + oddDigits (firstNo) + "</h4>";

    function reverseNo (firstNo) {
        let rev = 0;
        while (firstNo > 0) {
            let rem = firstNo % 10;
            rev = rev * 10 + rem;
            firstNo = Math.floor (firstNo / 10); 
        }
        return rev;
    }
    msg3.innerHTML = "<h4>" + reverseNo (firstNo) + "</h4>";

    function palindrome (firstNo) {
        let rev = 0;
        let no = firstNo;
        while (no > 0) {
            let rem = no % 10;
            rev = rev * 10 + rem;
            no = Math.floor (no / 10);
        }
        if(rev === firstNo) {
            return "Yes";
        } else {
            return "No";
        }
    }
    msg4.innerHTML = "<h4>" + palindrome (firstNo) + "</h4>";

    function armstong (firstNo) {
        let count = 0, arm = 0;
        let no = firstNo;
        while (no > 0) {
            no = Math.floor (no / 10);
            count++;
        }
        no = firstNo;
        while (no > 0) {
            let prod = 1;
            let rem = no % 10;
            for (let counter=1; counter<=count; counter++) {
                prod = prod * rem;
            }
            arm = arm + prod;
            no = Math.floor (no / 10);
        }
        if (arm == firstNo) {
            return "Yes";
        } else {
            return "No";
        }
    }
    msg5.innerHTML = "<h4>" + armstong (firstNo) + "</h4>";
};

